﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool Is_num(string num)
        {
            MessageBox.Show("Is_num: " + num);
            bool flag = false,flag1=true;
            string numbers = "0123456789";            
            for(int charCounter = 0;charCounter<num.Length;charCounter++)
            {
                flag = false;
                foreach(char numin in numbers)
                {
                    if ((char)num[charCounter] == numin) { flag = true;MessageBox.Show(num[charCounter]+"="+numin); break; }
                }
                if (flag == false) { MessageBox.Show("error num: " + num[charCounter]); flag1 = false; break; }
            }
            if (flag1) { MessageBox.Show("True number"); }
            return flag1;
        }

        static void MatchesFinder(string word, string str, out int count)
        {
            int counter = 0;
            while (true) {
                if (!str.Contains(word) || str == "" || word == "" ) { break; }
                int first_letter = str.IndexOf(word[0]);
                int len = word.Length;

                MessageBox.Show(string.Format("from {0}({1:d}) to {2}({3:d})", str[first_letter], first_letter, str[first_letter + len -1], first_letter + len-1));

                str =  str.Remove(first_letter, word.Length);

                MessageBox.Show(str);

                counter++;
            }
            count = counter;

        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                comboBox.Items.Add(comboBox.Text);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string findStr = textBox1.Text, mainStr = comboBox.Text;

            MatchesFinder(findStr, mainStr, out int count);
                     
            label2.Text = "найдено "+count+" раз";
        }
    }
}

